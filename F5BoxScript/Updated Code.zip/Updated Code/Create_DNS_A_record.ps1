
<#

.SYNOPSIS
#Aim: Create DNS A Record -------------------------------#
#Author: Vidya Hirlekar-------------------------------------#
#Date of development: 22-June-2015----------------------------#
#--------work Flow-------#
If DNS A record does not exist then create it.
I/P - A Record Name, IP, Server Name
O/P - 0 on success and DNS A record is created successfully
	  10 if Record exists
	  2 on error in creating the record.
#>

Import-Module DnsServer
#Create the new log for writing
New-Log $filepath "Create_DNS_A_Record.log"

function CheckDNS_A_Record($A_Record_Name, $IPV4_Addr, $S_Name, $Zone_Name)
{
	Try
	{

		if(($A_Record_Name) -and ($Zone_Name))
		{
			$A_Record_Name_status = get-DNSServerResourceRecord -zonename $Zone_Name 
				if($A_Record_Name_status -contains $A_Record_Name) # if DNS A exists
				{
					write-log "Record A exists. Can not create the DNS A record." 10
					return 10
				}
				elseif(($IPV4_Addr) -and ($S_Name))
				{
					Add-DnsServerResourceRecordA -Name $A_Record_Name -IPv4Address $IPV4_Addr -ZoneName powershell.local -computername $S_Name
					write-log "DNS A record created successfully. " 0
					return 0
				}
				else
				{
					write-log "Invalid or Blank input passed. Can not create the DNS A record." 2
					return 2
				}
		}

	}
	
	catch[System.Exception]
	{
		$outputDesc = $_.Exception.Message
		write-log "Some error occured. Can not create the DNS A record. $outputDesc", 2
		return 2
	}
}

CheckDNS_A_Record $A_Record_Name $IPV4_Addr $S_Name